// ===== 更新期限管理フェーズ2：残日数しきい値の自動メール通知 =====
// Vercel Cron（vercel.json）から1日1回呼び出される想定。
//
// 仕様（2026-07-15 伊藤さん決定）：
// ・通知の粒度＝担当営業ごとに1日1通のダイジェスト（候補・しきい値ごとの個別メールではない）
// ・宛先＝TO: 担当営業（該当部門）／CC: SSC・管理部（全員）
// ・対象しきい値＝残日数45/30/20/14/7日（RenewalCandidate.status が pending/csv_pending の
//   ものだけ。ready（送付準備完了）・not_renewing（更新しない確定）は対象外）
// ・重複送信防止＝renewal_candidates.notified_thresholds に送信済みしきい値を記録し、
//   同じしきい値では二度と送らない。しきい値をまたいで一気に進んだ場合（cron停止等）は、
//   最も近い（＝最も緊急度が高い）しきい値でまとめて1回通知し、飛ばした分もすべて
//   notified_thresholds に記録して後から重複通知しないようにする。
// ・期限超過（残日数<0）の案件は、しきい値を使い切った後も未解決である限り毎日ダイジェストに
//   含め続ける（サイレントに放置されないようにするため）。
// ・本番稼働前の現状（実アカウントが未整備）を踏まえ、RENEWAL_NOTIFY_OVERRIDE_EMAIL を設定すると
//   実際の宛先の代わりにそのアドレス（伊藤さんのメールアドレスを想定）へ送り、本文に本来の
//   宛先を注記する。本番切替時はこの環境変数を削除するだけでよい（docs/SYSTEM_DESIGN.md
//   9-2章「本番前に解除必須」リストに追加済み）。
// ・RENEWAL_NOTIFY_ENABLED を明示的に 'false' にすると送信自体を完全に止められる（緊急停止用）。
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import * as JapaneseHolidays from 'japanese-holidays'
import { sendRenewalDigestMail, sendRenewalSyncFailureNoticeMail, type RenewalDigestItem } from '@/lib/mail'
import { runRenewalCandidatesSync } from '@/lib/renewalCandidatesSync'
import { excludeRetiredStaffOr } from '@/lib/staffFilters'
import { listAllAuthUsers } from '@/lib/listAllAuthUsers'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const THRESHOLDS = [45, 30, 20, 14, 7] as const

function remainingDays(employEnd: string | null, dispatchEnd: string | null): number | null {
  const target = employEnd || dispatchEnd
  if (!target) return null
  const today = new Date(); today.setHours(0, 0, 0, 0)
  const end = new Date(target); end.setHours(0, 0, 0, 0)
  return Math.floor((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
}

export async function GET(req: NextRequest) {
  // Vercel Cronは環境変数名がCRON_SECRETの場合、Authorization: Bearer <値>を自動付与する。
  // 手動実行や外部からの不正実行を防ぐため必須チェックとする。
  const cronSecret = process.env.CRON_SECRET
  const authHeader = req.headers.get('authorization') || ''
  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  if (process.env.RENEWAL_NOTIFY_ENABLED === 'false') {
    return NextResponse.json({ skipped: true, reason: 'RENEWAL_NOTIFY_ENABLED=false' })
  }

  // 2026-07-21追加（伊藤さん決定）：弊社は土日祝が休みのため、その日は自動通知メールを送らない。
  // サーバーはUTCで動くため、日本時間（Asia/Tokyo）の日付に変換した上で土日・祝日を判定する
  // （Vercel Cronの実行時刻自体はJST10:00固定・vercel.json参照だが、念のため日付計算はここで
  // 明示的にJSTに揃える）。祝日判定は`japanese-holidays`ライブラリに委譲し、自前でのリスト
  // 保守は行わない方針とした（伊藤さんとの相談・2026-07-21決定。ライブラリの更新停止リスクは
  // あるが、導入・運用の手間が最小のため採用）。
  const jstTodayStr = new Date().toLocaleString('en-US', { timeZone: 'Asia/Tokyo' })
  const jstToday = new Date(jstTodayStr)
  const jstDayOfWeek = jstToday.getDay() // 0=日, 6=土
  const isWeekend = jstDayOfWeek === 0 || jstDayOfWeek === 6
  const holidayName = JapaneseHolidays.isHoliday(jstToday)
  if (isWeekend || holidayName) {
    return NextResponse.json({
      skipped: true,
      reason: isWeekend ? '土日のため送信をスキップしました' : `祝日（${holidayName}）のため送信をスキップしました`,
    })
  }

  const overrideEmail = process.env.RENEWAL_NOTIFY_OVERRIDE_EMAIL || null

  // ===== B-17対応（2026-08-12）：ダッシュボードを誰も開かなくても一覧が最新化されるようにする =====
  // 従来、renewal_candidates行を作る「同期」処理は3ダッシュボードのクライアント側initからしか
  // 呼ばれておらず、連休等で誰も開かない期間が続くと候補行自体が作られず、しきい値通知が
  // まとめて飛ばされる問題があった（外部総合品質監査レポートB-17）。cronが判定前に必ず同期を
  // 実行するようにし、ダッシュボードを開く行為に依存しない設計にする。一時的な失敗（通信の
  // 瞬間的な不調等）はcronの実行内で1回だけ自動的にやり直し、それでも失敗した場合は今日の
  // 通知自体は止めず既存データで続行する（同期の失敗で通知そのものを止めると、今回直そうと
  // している「通知が飛ばされる」問題を別の形で再発させるため）。
  let syncFailureMessage: string | null = null
  for (let attempt = 1; attempt <= 2; attempt++) {
    const result = await runRenewalCandidatesSync(supabaseAdmin)
    if (result.ok) { syncFailureMessage = null; break }
    syncFailureMessage = result.error
  }

  // M-12対応（2026-08-14）：select('*')にlimit/rangeが無く、PostgRESTの既定上限（1000件）に
  // 抵触すると1001件目以降が静かに切り捨てられ、しきい値到達の通知対象から漏れる不具合が
  // あった（対象が増えるほど悪化する）。.range()で全件をページング取得する形に変更する。
  const candidatesRaw: any[] = []
  {
    const PAGE_SIZE = 1000
    let from = 0
    for (let i = 0; i < 100; i++) { // 安全弁：本来あり得ない件数（最大10万件相当）に達したら打ち切る
      const { data, error: candidatesError } = await supabaseAdmin
        .from('renewal_candidates')
        .select('*')
        .in('status', ['pending', 'csv_pending'])
        .range(from, from + PAGE_SIZE - 1)
      if (candidatesError) {
        return NextResponse.json({ error: '更新候補の取得に失敗しました: ' + candidatesError.message }, { status: 500 })
      }
      const page = data || []
      candidatesRaw.push(...page)
      if (page.length < PAGE_SIZE) break
      from += PAGE_SIZE
    }
  }

  // B-17対応：画面（fetchCandidates）は表示直前に「現在退職済み・退職予定のスタッフ」を
  // 再チェックして除外しているが、cronのこの判定処理には同様のチェックが無かったため、
  // 画面のどこにも表示されない案件について通知メールだけ毎営業日届き続けるという食い違いが
  // あった。画面と同じ考え方（DBクエリ側での絞り込み）をここにも適用する。
  const empNosForRetiredCheck = Array.from(new Set((candidatesRaw || []).map((c: any) => c.employee_number)))
  let activeEmpNoSet = new Set<string>()
  if (empNosForRetiredCheck.length > 0) {
    const [retiredAtOk, retirementScheduledOk] = excludeRetiredStaffOr()
    const { data: activeStaffRows } = await supabaseAdmin
      .from('staff')
      .select('employee_number')
      .in('employee_number', empNosForRetiredCheck)
      .or(retiredAtOk).or(retirementScheduledOk)
    activeEmpNoSet = new Set((activeStaffRows || []).map((s: any) => s.employee_number))
  }
  const candidates = (candidatesRaw || []).filter((c: any) => activeEmpNoSet.has(c.employee_number))

  // しきい値到達判定。newlyCrossedのどれかがあれば今日のダイジェストに含める。
  type Targeted = { candidate: any; item: RenewalDigestItem; newlyCrossed: number[] }
  const targeted: Targeted[] = []

  for (const c of candidates) {
    const days = remainingDays(c.employ_end_date, c.dispatch_end_date)
    if (days === null) continue
    const notified: number[] = c.notified_thresholds || []

    const newlyCrossed = THRESHOLDS.filter(t => days <= t && !notified.includes(t))
    const alreadyFullyNotified = THRESHOLDS.every(t => notified.includes(t))
    const isOverdueStillUnresolved = days < 0 && alreadyFullyNotified

    if (newlyCrossed.length === 0 && !isOverdueStillUnresolved) continue

    targeted.push({
      candidate: c,
      item: {
        staffName: c.staff_name,
        workLocationName: c.work_location_name,
        remainingDays: days,
        employEndDate: c.employ_end_date,
        dispatchEndDate: c.dispatch_end_date,
      },
      newlyCrossed,
    })
  }

  // 部門マスタ・宛先（staff_roles＋auth.usersのメール）をまとめて取得
  // （targeted.length===0でも、同期失敗時の単独通知の宛先解決に必要なため早めに計算する）
  const { data: deptRows } = await supabaseAdmin.from('department_master').select('dept_no, dept_name')
  const deptNameByNo = new Map<number, string>((deptRows || []).map((d: any) => [d.dept_no, d.dept_name]))

  const { data: roleRows } = await supabaseAdmin.from('staff_roles').select('id, role, dept_no')
  // M-11対応（2026-08-14）：以前は1ページ目（perPage:200）しか取得しておらず、アカウント数が
  // 200を超えると201人目以降が通知先から静かに欠落する不具合があった。全件取得するヘルパーへ変更。
  const allAuthUsers = await listAllAuthUsers(supabaseAdmin)
  const emailById = new Map<string, string>(allAuthUsers.map(u => [u.id, u.email || '']))

  const sscEmails = Array.from(new Set(
    (roleRows || [])
      .filter((r: any) => r.role === 'SSC')
      .map((r: any) => emailById.get(r.id))
      .filter((e): e is string => !!e)
  ))
  const mgmtEmails = Array.from(new Set(
    (roleRows || [])
      .filter((r: any) => r.role === '管理部')
      .map((r: any) => emailById.get(r.id))
      .filter((e): e is string => !!e)
  ))
  const ccEmails = Array.from(new Set([...sscEmails, ...mgmtEmails]))

  if (targeted.length === 0) {
    // B-17対応：本日通知対象が無い場合、通常はダイジェストメール自体が送られないため、
    // 同期の失敗が完全に無言のまま終わってしまう。この場合だけ、失敗の事実を伝える
    // 単独メールを管理部宛に送る（技術的なエラー文は載せず、状況と見通しのみ伝える）。
    if (syncFailureMessage) {
      const failureTo = overrideEmail ? [overrideEmail] : mgmtEmails
      const failureCc = overrideEmail ? [] : sscEmails
      try {
        await sendRenewalSyncFailureNoticeMail(failureTo, failureCc)
      } catch (e: any) {
        console.error('更新期限：同期失敗の単独通知メール送信エラー:', e?.message || e)
      }
    }
    return NextResponse.json({ sent: 0, message: '本日対象の更新候補はありませんでした。', syncFailed: !!syncFailureMessage })
  }

  // 部門ごとにグルーピング
  const byDept = new Map<number | null, Targeted[]>()
  for (const t of targeted) {
    const key = t.candidate.dept_no ?? null
    if (!byDept.has(key)) byDept.set(key, [])
    byDept.get(key)!.push(t)
  }

  let sentCount = 0
  const results: any[] = []

  for (const [deptNo, items] of byDept.entries()) {
    const deptName = deptNo !== null ? (deptNameByNo.get(deptNo) || `部門No.${deptNo}`) : '部門未設定'
    const assignedToEmails = deptNo !== null
      ? Array.from(new Set(
          (roleRows || [])
            .filter((r: any) => r.role === '担当営業' && r.dept_no === deptNo)
            .map((r: any) => emailById.get(r.id))
            .filter((e): e is string => !!e)
        ))
      : []

    // 総合レビュー指摘N対応（2026-07-16）：部門未設定・担当営業アカウント未登録等で
    // 本来の宛先（担当営業）が1件も特定できない場合、以前はここで送信自体をスキップしており、
    // override環境変数を外した本番運用では「誰にも通知が届かない＝更新漏れ」の恐れがあった。
    // 担当者が特定できない案件は、管理部宛にフォールバック送信することで通知の空白を無くす。
    const isUnassignedFallback = assignedToEmails.length === 0
    const toEmails = isUnassignedFallback ? mgmtEmails : assignedToEmails
    const ccForThisDept = isUnassignedFallback ? sscEmails : ccEmails

    const realTo = toEmails
    const realCc = ccForThisDept
    let finalTo = toEmails
    let finalCc = ccForThisDept
    let overrideNotice: string | undefined

    if (overrideEmail) {
      finalTo = [overrideEmail]
      finalCc = []
      overrideNotice = `※現在テスト運用中のため、本来の宛先ではなくこのアドレスに届いています。\n　本来のTO：${realTo.join(', ') || '(該当する担当営業・管理部アカウントなし)'}\n　本来のCC：${realCc.join(', ') || '(なし)'}`
    }

    // B-17対応：同期が2回とも失敗した日は、通常どおり管理部がCCに入っているこのダイジェスト
    // メールの文末に一言添えて伝える（新しい通知先・監視の仕組みを作らず、既にCCで日常的に
    // 目にしているメールに乗せることで確実に気づける形にする。伊藤さんとの合意事項）。
    if (syncFailureMessage) {
      const syncNotice = '本日の自動更新は完了しませんでした。前回正常に更新された時点のデータに基づいて通知しています。通常は翌日以降の処理で自然に復旧します。'
      overrideNotice = overrideNotice ? `${overrideNotice}\n\n${syncNotice}` : syncNotice
    }

    if (finalTo.length === 0) {
      results.push({ deptNo, deptName, sent: false, reason: '送信先メールアドレスが見つかりませんでした（担当営業アカウント未登録・管理部フォールバックも0件）' })
      continue
    }

    try {
      await sendRenewalDigestMail(finalTo, finalCc, deptName, items.map(t => t.item), overrideNotice, isUnassignedFallback)
      sentCount++
      results.push({ deptNo, deptName, sent: true, count: items.length })

      const now = new Date().toISOString()
      await Promise.all(items.map(t => {
        const notified: number[] = t.candidate.notified_thresholds || []
        const merged = Array.from(new Set([...notified, ...t.newlyCrossed]))
        return supabaseAdmin
          .from('renewal_candidates')
          .update({ notified_thresholds: merged, last_notified_at: now })
          .eq('id', t.candidate.id)
      }))
    } catch (e: any) {
      results.push({ deptNo, deptName, sent: false, reason: 'メール送信エラー: ' + (e?.message || '') })
    }
  }

  return NextResponse.json({ sent: sentCount, totalDepts: byDept.size, results })
}
