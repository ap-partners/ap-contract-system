'use client'

import { useEffect, useRef, useState, type ReactNode } from 'react'
import { supabase, getAuthHeader } from '@/lib/supabase'
import { useSessionCollisionGuard } from '@/lib/useSessionCollisionGuard'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import {
  ContractStatus,
  ContractForDisplay,
  formatDateTime,
  getDocumentLabel,
  ContractTypeBadge,
  ContractStatusBadge,
  ConfirmedBadge,
  getDeadlineAlert,
  getEmployPeriodLabel,
} from '../_shared/contractDisplay'
// 2026-08-05：日付表記統一によりハイフン生値表示（2026-05-01）を廃止し漢字表記へ
import { formatPeriodJp } from '@/lib/dateFormat'
import { WITHDRAWN_APPLICATION_DELETE_CONFIRM } from '@/lib/confirmMessages'
import { useContractListToolbar, buildDateSortOptions } from '../_shared/useContractListToolbar'
import { useApprovedAccumulator, APPROVED_WINDOW_DAYS } from '../_shared/useApprovedAccumulator'
import RenewalManagementTab from '../_shared/RenewalManagementTab'
import WageRevisionSection from '../_shared/WageRevisionSection'
import { useWageRevisionCandidates } from '../_shared/useWageRevisionCandidates'
import ContractMonitoringSection from '../_shared/ContractMonitoringSection'
import { useContractMonitoring } from '../_shared/useContractMonitoring'
import PledgeListSection from '../_shared/PledgeListSection'
import LoggedInUserChip from '../_shared/LoggedInUserChip'
import NewDocumentMenu from '../_shared/NewDocumentMenu'
import ChatbotWidget from '../_shared/ChatbotWidget'
import { useRenewalCandidates } from '../_shared/useRenewalCandidates'
import { useDebouncedSearch } from '../_shared/useDebouncedSearch'
import { SubTabBar } from '../_shared/SubTabBar'
import { getDeptSearchScope } from '@/app/apply/_lib/helpers'
import { useToast } from '@/app/_shared/ui/ToastProvider'
import { useConfirm } from '@/app/_shared/ui/ConfirmDialog'
import ValidationBanner from '@/app/_shared/ui/ValidationBanner'

type Contract = ContractForDisplay & {
  created_by_dept_no: number | null
  sign_requested_at: string | null
}

// 更新期限管理タブのサブタブ（2026-07-29：最低賃金改定対応の追加に伴い新設。admin/page.tsxと同じ考え方。
// 2026-08-03：契約状況モニタリングを担当営業にも「閲覧のみ・自部門のみ」で追加）
type RenewalSubTab = 'candidates' | 'wageRevision' | 'monitoring'

type MyRequest = {
  id: string
  request_type: 'staff_register' | 'csv_import'
  staff_name: string | null
  staff_code: string | null
  staff_dept: string | null
  staff_hire_date: string | null
  client_name: string | null
  system_type: string | null
  dispatch_start_date: string | null
  staff_register_status: string | null
  csv_import_status: string | null
  staff_register_cancel_reason: string | null
  csv_import_cancel_reason: string | null
  requested_by_name: string | null
  requested_by_dept: string | null
  requested_at: string
}

type FilterKey = 'pending' | 'explain' | 'rejected' | 'waiting' | 'completed' | 'withdrawn' | 'other' | 'renewal' | 'pledges'
type IconName = 'file' | 'message' | 'refresh' | 'pen' | 'check' | 'mail' | 'search' | 'filter' | 'map' | 'arrow' | 'logout' | 'plus' | 'alert' | 'clock'

const SIGN_DEADLINE_DAYS = 7 // 署名期日＝通知から7日（初期値。将来アラート日数マスタで変更可能にする予定）
const REQUEST_WINDOW_DAYS = 45 // 依頼状況タブの既定表示期間（2026-07-14。契約側と同じ考え方）
const CLOSING_PATTERN_LABEL: Record<string, string> = {
  auto: '指定なし',
  face: '対面でその場説明',
  print: '印刷して説明後にリンク送付',
}

const cardBase = 'rounded-[18px] border border-[#E8EDF5] bg-white shadow-[0_10px_30px_rgba(15,23,42,.05)] transition hover:-translate-y-0.5 hover:shadow-[0_15px_40px_rgba(15,23,42,.08)]'
const primaryButton = 'inline-flex h-[52px] shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-2xl bg-[#2F5FD0] px-6 text-sm font-semibold text-white shadow-[0_10px_24px_rgba(47,95,208,.22)] transition hover:-translate-y-0.5 hover:bg-[#244CB3] hover:shadow-[0_15px_34px_rgba(47,95,208,.26)]'
const secondaryButton = 'inline-flex h-[52px] shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-2xl border border-[#E8EDF5] bg-white px-6 text-sm font-semibold text-[#1F2937] transition hover:-translate-y-0.5 hover:border-[#2F5FD0] hover:text-[#2F5FD0]'
const accentButton = 'inline-flex h-[52px] shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-2xl bg-[#F59E42] px-6 text-sm font-semibold text-white shadow-[0_10px_24px_rgba(245,158,66,.2)] transition hover:-translate-y-0.5 hover:bg-[#E88525] hover:shadow-[0_15px_34px_rgba(245,158,66,.28)]'
// 2026-07-24追加：ヘッダー専用ボタンスタイル。SSCダッシュボードのヘッダー（h-12・px-4）に
// 3ダッシュボードとも統一するための専用定数（本文中の他のprimaryButton等はh-[52px]のまま変更しない）。
// 2026-07-24：新規発行ボタン統合（NewDocumentMenu）によりheaderPrimaryButton/headerAccentButtonは不要になり削除。
const headerSecondaryButton = 'flex h-12 items-center gap-2 rounded-2xl border border-[#E8EDF5] bg-white px-4 text-sm font-semibold text-[#1F2937] shadow-[0_10px_30px_rgba(15,23,42,.04)] transition hover:-translate-y-0.5 hover:border-[#2F5FD0] hover:text-[#2F5FD0] hover:shadow-[0_15px_40px_rgba(15,23,42,.08)]'

// Dateオブジェクト専用（呼び出し元がnew Date()で渡してくるため）。
// toISOString()経由でformatDateJp（文字列用）に委譲するとローカル時刻→UTC変換で日付がずれる
// （JST 0時=UTC前日15時）ため、ローカルの年月日をそのまま漢字表記に組み立てる。
const formatDate = (d: Date) => `${d.getFullYear()}年${String(d.getMonth() + 1).padStart(2, '0')}月${String(d.getDate()).padStart(2, '0')}日`

const Icon = ({ name, className = '' }: { name: IconName; className?: string }) => {
  const paths: Record<IconName, ReactNode> = {
    file: (
      <>
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <path d="M14 2v6h6" />
        <path d="M8 13h8" />
        <path d="M8 17h5" />
      </>
    ),
    message: (
      <>
        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 8.5-8.5h.5a8.48 8.48 0 0 1 8 8v.5z" />
      </>
    ),
    refresh: (
      <>
        <path d="M21 12a9 9 0 0 1-15.5 6.2" />
        <path d="M3 12A9 9 0 0 1 18.5 5.8" />
        <path d="M18 2v4h4" />
        <path d="M6 22v-4H2" />
      </>
    ),
    pen: (
      <>
        <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
      </>
    ),
    check: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="m8 12 3 3 5-6" />
      </>
    ),
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m3 7 9 6 9-6" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-3.5-3.5" />
      </>
    ),
    filter: (
      <>
        <path d="M3 5h18" />
        <path d="M7 12h10" />
        <path d="M10 19h4" />
      </>
    ),
    map: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0z" />
        <circle cx="12" cy="10" r="3" />
      </>
    ),
    arrow: (
      <>
        <path d="M5 12h14" />
        <path d="m13 6 6 6-6 6" />
      </>
    ),
    logout: (
      <>
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        <path d="m16 17 5-5-5-5" />
        <path d="M21 12H9" />
      </>
    ),
    plus: (
      <>
        <path d="M14 3v4a1 1 0 0 0 1 1h4" />
        <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
        <path d="M12 12v5" />
        <path d="M9.5 14.5h5" />
      </>
    ),
    alert: (
      <>
        <path d="M10.3 3.9 2.5 17.4A2 2 0 0 0 4.2 20h15.6a2 2 0 0 0 1.7-2.6L13.7 3.9a2 2 0 0 0-3.4 0z" />
        <path d="M12 8v5" />
        <path d="M12 17h.01" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
  }

  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  )
}

const Pill = ({ children, tone = 'gray' }: { children: ReactNode; tone?: 'blue' | 'orange' | 'red' | 'green' | 'gray' | 'purple' }) => {
  const tones = {
    blue: 'bg-[#EAF1FF] text-[#2F5FD0]',
    orange: 'bg-[#FFF3E8] text-[#F59E42]',
    red: 'bg-[#FDECEC] text-[#E74C3C]',
    green: 'bg-[#EAF8EE] text-[#4CAF50]',
    gray: 'bg-[#F3F5F8] text-[#6B7280]',
    purple: 'bg-[#F3ECFF] text-[#7C3AED]',
  }
  return <span className={`inline-flex items-center whitespace-nowrap rounded-full px-3 py-1 text-xs font-semibold ${tones[tone]}`}>{children}</span>
}

const SignDeadlineBadge = ({ signRequestedAt }: { signRequestedAt: string | null }) => {
  if (!signRequestedAt) return null
  const notified = new Date(signRequestedAt)
  const deadline = new Date(notified.getTime() + SIGN_DEADLINE_DAYS * 24 * 60 * 60 * 1000)
  const today = new Date(); today.setHours(0, 0, 0, 0)
  const deadlineDay = new Date(deadline); deadlineDay.setHours(0, 0, 0, 0)
  const remain = Math.floor((deadlineDay.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
  const overdue = remain < 0
  const urgent = !overdue && remain <= 2
  const label = overdue ? `期限超過${Math.abs(remain)}日（${formatDate(deadline)}）` : `期限まで${remain}日（${formatDate(deadline)}）`

  return <Pill tone={overdue ? 'red' : urgent ? 'orange' : 'blue'}>{label}</Pill>
}

// M-20対応（2026-08-14）：以前はSalesDashboard関数の内側で定義されており、親が
// 再レンダーされるたびに「新しい部品」として扱われ、一覧表示中のカードDOMが毎回作り直されて
// いた（検索欄に1文字打つたびに表示中の全カードが破棄・再生成される等。外部総合品質監査
// レポートM-20）。モジュールトップレベルへ移し、必要な値はpropsで受け取る形に変更する。
function ContractCard({
  contract, router, confirmingExplainId, setConfirmingExplainId,
  deletingWithdrawnId, handleDeleteWithdrawn, isExplainNeeded,
  explainLoading, handleExplainDone,
}: {
  contract: Contract
  router: ReturnType<typeof useRouter>
  confirmingExplainId: string | null
  setConfirmingExplainId: (id: string | null) => void
  deletingWithdrawnId: string | null
  handleDeleteWithdrawn: (contractId: string) => void
  isExplainNeeded: (c: Contract) => boolean
  explainLoading: boolean
  handleExplainDone: (contractId: string) => void
}) {
  const staff = contract.input_data?.staff || {}
  const f = contract.input_data?.fields || {}
  const deadline = getDeadlineAlert(contract)
  const isWaitingSign = contract.status === '署名待ち'
  const isConfirmed = contract.status === '署名済み' || contract.status === '完了'
  const isExplain = isExplainNeeded(contract)

  return (
    <article className={`${cardBase} p-5`}>
      {/* 1行目：氏名と操作ボタンは画面幅に関わらず必ずこの1行に収まる（総合レビュー追加指摘・
          2026-07-29対応：固定ピクセル幅の横並びグリッドだと画面が狭いと操作ボタンごと見切れて
          しまっていたため、氏名＋ボタンだけは常に見える構造に変更） */}
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            {deadline.type && !isWaitingSign && (
              <Pill tone={deadline.type === 'overdue' ? 'red' : 'orange'}>{deadline.label}</Pill>
            )}
            {isExplain && <Pill tone="orange">説明対応が必要</Pill>}
          </div>
          <p className="break-words text-[22px] font-semibold leading-7 text-[#1F2937]">{staff.name || '-'}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm font-medium text-[#6B7280]">
            <span className="break-words">{staff.department || '-'}</span>
            <span className="h-3 w-px bg-[#E8EDF5]" />
            <span>{staff.employee_number || '-'}</span>
            <ContractTypeBadge contractType={f.contractType || contract.contract_type} workPlace={f.workPlace || contract.work_place} />
          </div>
        </div>

        <div className="flex shrink-0 flex-col items-end gap-2">
          <button
            className={isExplain || contract.status === '差し戻し中' ? secondaryButton : primaryButton}
            onClick={() => router.push(`/dashboard/sales/contracts/${contract.id}`)}
          >
            詳細を見る
            <Icon name="arrow" className="h-4 w-4" />
          </button>
          {isExplain && confirmingExplainId !== contract.id && (
            <button className={primaryButton} onClick={() => setConfirmingExplainId(contract.id)}>
              <Icon name="check" className="h-4 w-4" />
              説明完了
            </button>
          )}
          {contract.status === '差し戻し中' && (
            <button className={accentButton} onClick={() => router.push(`/apply?edit=${contract.id}`)}>
              再申請する
            </button>
          )}
          {contract.status === '取り下げ' && (
            <button
              className="inline-flex h-[52px] shrink-0 items-center justify-center whitespace-nowrap rounded-2xl border border-[#FCA5A5] bg-white px-4 text-sm font-semibold text-[#DC2626] transition hover:bg-[#FEF2F2] disabled:opacity-50"
              disabled={deletingWithdrawnId === contract.id}
              onClick={() => handleDeleteWithdrawn(contract.id)}
            >
              {deletingWithdrawnId === contract.id ? '削除中…' : '削除'}
            </button>
          )}
        </div>
      </div>

      {/* 2行目以降：補足情報は画面幅に応じて自動で折り返す */}
      <div className="mt-4 grid grid-cols-2 gap-4 border-t border-[#E8EDF5] pt-4 sm:grid-cols-4">
        <div className="min-w-0">
          <p className="mb-2 text-xs font-semibold text-[#6B7280]">就業先</p>
          <div className="flex items-start gap-2">
            <Icon name="map" className="mt-0.5 h-4 w-4 shrink-0 text-[#2F5FD0]" />
            <p className="min-w-0 truncate text-sm font-medium leading-6 text-[#1F2937]" title={f.workLocationName || '-'}>{f.workLocationName || '-'}</p>
          </div>
        </div>

        <div className="min-w-0">
          <p className="mb-2 text-xs font-semibold text-[#6B7280]">ステータス</p>
          <div className="flex flex-wrap gap-2">
            <Pill tone="blue">{getDocumentLabel(contract.document_type, contract.pattern)}</Pill>
            <ContractStatusBadge
              status={contract.status}
              isInternal={(f.workPlace || contract.work_place) === '社内'}
              overrideLabel={isExplain ? '説明対応が必要' : undefined}
            />
            {isWaitingSign && <SignDeadlineBadge signRequestedAt={contract.sign_requested_at} />}
            {isConfirmed && <ConfirmedBadge signedAt={contract.signed_at} />}
          </div>
        </div>

        <div className="min-w-0">
          <p className="mb-2 text-xs font-semibold text-[#6B7280]">雇用期間</p>
          <p className="break-words text-xs font-medium leading-5 text-[#1F2937]">{getEmployPeriodLabel(contract)}</p>
          {(contract.pattern === 'B' || contract.pattern === 'C') && f.dispatchStart && f.dispatchEnd && (
            <p className="mt-1 break-words text-xs font-medium leading-5 text-[#6B7280]">派遣期間 {formatPeriodJp(f.dispatchStart, f.dispatchEnd)}</p>
          )}
          {isExplain && f.closingPattern && (
            <p className="mt-1 break-words text-xs font-medium leading-5 text-[#6B7280]">締結パターン {CLOSING_PATTERN_LABEL[f.closingPattern] || f.closingPattern}</p>
          )}
        </div>

        <div className="min-w-0">
          <p className="mb-2 text-xs font-semibold text-[#6B7280]">申請日時</p>
          <p className="break-words text-sm font-medium leading-6 text-[#1F2937]">{formatDateTime(contract.created_at)}</p>
        </div>
      </div>

      {contract.status === '差し戻し中' && contract.rejection_reason && (
        <div className="mt-4 rounded-2xl border border-[#FFE2C7] bg-[#FFF8F1] p-4">
          <p className="text-xs font-semibold text-[#F59E42]">差し戻し理由</p>
          <p className="mt-2 break-words text-sm font-medium leading-6 text-[#1F2937]">{contract.rejection_reason}</p>
        </div>
      )}

      {contract.status === '取り下げ' && (
        <div className="mt-4 rounded-2xl border border-[#E5E7EB] bg-[#F9FAFB] p-4">
          <p className="text-xs font-semibold text-[#6B7280]">取り下げ理由{contract.withdrawn_at ? `（${formatDateTime(contract.withdrawn_at)}）` : ''}</p>
          <p className="mt-2 break-words text-sm font-medium leading-6 text-[#1F2937]">{contract.withdrawn_reason || '（理由の入力なし）'}</p>
        </div>
      )}

      {isExplain && contract.status === 'SSC承認済み' && (
        <div className="mt-4 rounded-2xl border border-[#D7E5FF] bg-[#F5F9FF] p-4">
          <p className="text-sm font-medium leading-6 text-[#2F5FD0]">
            {contract.work_place === '社内'
              ? '承認済みです。従業員への説明が完了したら「説明完了」を押してください。押すと従業員が署名待ちの状態になります。'
              : 'SSC承認済みです。従業員への説明が完了したら「説明完了」を押してください。押すと従業員が署名待ちの状態になります。'}
          </p>
        </div>
      )}

      {isExplain && confirmingExplainId === contract.id && (
        <div className="mt-4 rounded-2xl border border-[#D7E5FF] bg-[#F5F9FF] p-4">
          <p className="text-sm font-semibold text-[#1F2937]">従業員への説明は完了しましたか？</p>
          <p className="mt-2 text-sm font-medium leading-6 text-[#6B7280]">押すと、従業員が署名待ちの状態に切り替わります。</p>
          <div className="mt-4 flex flex-col gap-3 sm:flex-row">
            <button
              onClick={() => handleExplainDone(contract.id)}
              disabled={explainLoading}
              className={`${primaryButton} flex-1 disabled:cursor-not-allowed disabled:opacity-50`}
            >
              {explainLoading ? '処理中...' : '説明完了'}
            </button>
            <button onClick={() => setConfirmingExplainId(null)} className={secondaryButton}>
              キャンセル
            </button>
          </div>
        </div>
      )}
    </article>
  )
}

export default function SalesDashboard() {
  const router = useRouter()
  const { showError, showSuccess } = useToast()
  const confirmDialog = useConfirm()
  const [user, setUser] = useState<any>(null)
  // 総合レビュー（QA監査2026-07-22）指摘C1対応：別タブで別アカウントにログインされ
  // 認証情報が裏で切り替わったことを検知したら、安全のため強制ログアウトする
  useSessionCollisionGuard(user?.id)
  const [deptLookupError, setDeptLookupError] = useState('')
  // 「完了」（署名済み・完了）は蓄積型のため共通フックで直近45日・ページ単位で取得する。
  // それ以外（進行中・要説明・差し戻し・署名待ち）はフロー型なので全件取得のまま。
  const [flowContracts, setFlowContracts] = useState<Contract[]>([])
  // 取り下げ済み申請の削除（2026-07-27追加）：status='取り下げ'の行のみDELETE可能なようRLSで制限済み。
  const [deletingWithdrawnId, setDeletingWithdrawnId] = useState<string | null>(null)
  const deptNoRef = useRef<number | null>(null)
  // グループ範囲（2026-07-29追加）：在籍スタッフ0名の統括部門（広域本部等）を選んだアカウントは、
  // 自部門1件だけでなくgetDeptSearchScope()が返す複数の実務部門をまとめて絞り込み対象にする。
  // 通常部門は従来通り自部門1件のみを含む配列になる（docs/SYSTEM_DESIGN.md 10章2026-07-29参照）。
  const deptScopeRef = useRef<number[]>([])
  const {
    approvedContracts, approvedTotalCount, approvedHasMore, approvedLoadingMore,
    approvedSearchMode, approvedSearching, approvedSearchNotice,
    fetchApprovedRecent, loadMoreApproved, runApprovedSearch,
  } = useApprovedAccumulator<Contract>(q => q.in('created_by_dept_no', deptScopeRef.current), ['署名済み', '完了'])
  const [loading, setLoading] = useState(true)
  const [activeFilter, setActiveFilter] = useState<FilterKey>('pending')
  // 総合レビュー指摘B対応（2026-07-16）：担当営業のタブが「ステータス（進行中/要説明/差し戻し/
  // 署名待ち/完了）」と「機能（依頼状況/更新期限管理）」を1階層に混在させており、管理部（機能タブ→
  // ステータスのサブタブという2階層）と文法が異なるという指摘。activeFilterの値自体は変えず
  // （既存のフィルタ・蓄積表示ロジックへの影響を避けるため）、タブの見せ方だけを「契約一覧／
  // 依頼状況／更新期限管理」の機能タブ＋契約一覧内のステータスのサブタブという2階層に変更する。
  // このrefは「契約一覧」タブに戻ったときに直前に見ていたステータスへ復帰するためのもの。
  const lastContractFilterRef = useRef<FilterKey>('pending')
  const [confirmingExplainId, setConfirmingExplainId] = useState<string | null>(null)
  const [explainLoading, setExplainLoading] = useState(false)
  const [myRequests, setMyRequests] = useState<MyRequest[]>([])
  const [myRequestsLoading, setMyRequestsLoading] = useState(true)
  const [includeCompletedRequests, setIncludeCompletedRequests] = useState(false)
  // 総合レビュー指摘33対応（2026-07-22）：依頼状況タブに検索欄が無く、管理部「依頼管理」との
  // 使い勝手の差が指摘されていたため追加。担当営業側は自部門・直近期間で既に件数が絞られた
  // データを画面側に持っているため、管理部のようにサーバーへ再クエリはせず、取得済みの
  // myRequestsに対してクライアント側でスタッフ名・社員番号を絞り込む（挙動はデバウンス込みで統一）。
  const { searchText: myRequestsSearchText, setSearchText: setMyRequestsSearchText, debouncedSearchText: myRequestsDebouncedSearchText } = useDebouncedSearch()
  // 依頼状況タブも、契約側と同じ理由（年数が経つとどんどん蓄積し件数が意味を持たなくなる）で
  // 既定は直近REQUEST_WINDOW_DAYS日のみ取得し、「全期間で表示」を押した時だけ全件取得する
  // （伊藤さん指摘・2026-07-14）
  const deptNameRef = useRef<string | null>(null)
  const [myRequestsWindowMode, setMyRequestsWindowMode] = useState<'recent' | 'all'>('recent')
  const {
    candidates: renewalCandidates, loading: renewalLoading,
    syncCandidates, fetchCandidates, updateCandidate,
    searchCsvRenewal, requestCsvImport, switchToManualOverride,
    copyDispatchToEmploy, confirmNotRenewing, setTriageMode, setRenewalTab, executeBulkApply,
  } = useRenewalCandidates()
  // 最低賃金改定対応（2026-07-29実装。担当営業は自部門分のみ。contractsのRLSで自動的に絞り込まれる）
  const [renewalSubTab, setRenewalSubTab] = useState<RenewalSubTab>('candidates')
  const {
    rows: wageRevisionRows, loading: wageRevisionLoading, error: wageRevisionError,
    fetchCandidates: fetchWageRevisionCandidates,
  } = useWageRevisionCandidates()
  // 契約状況モニタリング（2026-08-03追加。担当営業は閲覧のみ・自部門のみ。DB関数
  // get_contract_monitoring_status()側で担当営業ロールの場合のみ自部門グループに絞り込み済み）
  const {
    rows: monitoringRows, loading: monitoringLoading, error: monitoringError, fetchMonitoring,
  } = useContractMonitoring()

  useEffect(() => {
    const init = async () => {
      const { data } = await supabase.auth.getUser()
      if (!data.user) { router.push('/login'); return }
      const role = data.user.user_metadata?.role
      if (role !== '担当営業') { router.push('/login'); return }
      setUser(data.user)

      // 2026-07-29変更：所属部門の判定を、staffテーブル（email一致）からstaff_rolesテーブル
      // （本人のid一致）参照に統一。アカウント管理機能（2026-07-24新設・staff_rolesが正）とは
      // 無関係の古い仕組みが残っていたもので、在籍スタッフ0名の統括部門（広域本部等）のアカウントは
      // staffテーブルに該当行が無く機能しなかったため修正した（docs/SYSTEM_DESIGN.md 10章
      // 2026-07-29参照）。
      const { data: staffRoleRow, error: staffError } = await supabase
        .from('staff_roles')
        .select('dept_no, department_master(dept_name)')
        .eq('id', data.user.id)
        .maybeSingle()

      if (staffError || !staffRoleRow || staffRoleRow.dept_no === null) {
        setDeptLookupError('ログインユーザーの所属部門を特定できませんでした。管理部にご確認ください。')
        setLoading(false)
        setMyRequestsLoading(false)
        return
      }

      const deptName = (staffRoleRow as any)?.department_master?.dept_name || null
      deptNoRef.current = staffRoleRow.dept_no
      deptNameRef.current = deptName
      // グループ範囲（広域本部等）は自部門を含まない複数部門、通常部門は自部門1件のみの配列になる
      deptScopeRef.current = getDeptSearchScope(staffRoleRow.dept_no)

      await Promise.all([
        loadContracts(deptScopeRef.current),
        fetchApprovedRecent(),
        loadMyRequests(deptName),
        (async () => { await syncCandidates(); await fetchCandidates(deptScopeRef.current) })(),
        loadPledgesPendingCount(deptScopeRef.current),
        // 2026-07-29：最低賃金改定対応サブタブのピル件数が、サブタブを開くまで0件のまま表示される
        // 不具合防止のため（契約状況モニタリングと同じ理由）、ページ読み込み時に先読みする。
        fetchWageRevisionCandidates(),
        // 2026-08-03：契約状況モニタリングサブタブも同じ理由で先読みする（admin/page.tsxと同じ考え方）。
        fetchMonitoring(),
      ])
      setLoading(false)
    }
    init()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router])

  // アルバイト誓約書タブの承認待ち件数バッジ（2026-07-23追加。SSC・管理部と同じ考え方だが、
  // 担当営業は契約一覧と同様に自部門（created_by_dept_no）のみに絞り込む）
  const [pledgesPendingCount, setPledgesPendingCount] = useState(0)
  const loadPledgesPendingCount = async (deptNos: number[]) => {
    const { count } = await supabase
      .from('pledges')
      .select('id', { count: 'exact', head: true })
      .eq('status', '申請中')
      .in('created_by_dept_no', deptNos)
    setPledgesPendingCount(count || 0)
  }

  const loadMyRequests = async (deptName: string | null, windowMode: 'recent' | 'all' = 'recent') => {
    setMyRequestsLoading(true)
    if (!deptName) { setMyRequests([]); setMyRequestsLoading(false); return }
    let query = supabase
      .from('requests')
      .select('id, request_type, staff_name, staff_code, staff_dept, staff_hire_date, client_name, system_type, dispatch_start_date, staff_register_status, csv_import_status, staff_register_cancel_reason, csv_import_cancel_reason, requested_by_name, requested_by_dept, requested_at')
      .eq('requested_by_dept', deptName)
      .order('requested_at', { ascending: false })
    if (windowMode === 'recent') {
      const windowStart = new Date()
      windowStart.setDate(windowStart.getDate() - REQUEST_WINDOW_DAYS)
      query = query.gte('requested_at', windowStart.toISOString())
    } else {
      query = query.limit(300)
    }
    const { data: rows, error } = await query
    if (error) { console.error('requests取得エラー:', error); setMyRequestsLoading(false); return }
    setMyRequests((rows || []) as MyRequest[])
    setMyRequestsWindowMode(windowMode)
    setMyRequestsLoading(false)
  }

  // ===== 依頼（スタッフマスタ登録依頼／CSVインポート依頼）の自己取消（2026-07-24新設） =====
  // 従来は管理部の「依頼管理」タブにしか取消ボタンが無く、依頼した本人（担当営業）が
  // 間違えて依頼した場合に自分で取り消す手段が無かった。管理部側のhandleCancelTaskと同じ
  // 列（cancelled / cancel_reason）を使い、「未対応（pending）」の間だけ本人が取り消せるようにする。
  // .eq(statusField, 'pending')の条件を付け、管理部が既に対応中/完了/取消済みにしていた場合は
  // 上書きしない（競合防止）。
  const handleSelfCancelRequest = async (
    requestId: string,
    statusField: 'staff_register_status' | 'csv_import_status',
    reasonField: 'staff_register_cancel_reason' | 'csv_import_cancel_reason',
    reason: string
  ) => {
    const { data, error } = await supabase
      .from('requests')
      .update({ [statusField]: 'cancelled', [reasonField]: reason })
      .eq('id', requestId)
      .eq(statusField, 'pending')
      .select()
      .maybeSingle()
    if (error) { showError('取消の保存に失敗しました: ' + error.message); return false }
    if (!data) {
      showError('この依頼はすでに状況が変わっているため、取消できませんでした。画面を更新してご確認ください。')
      return false
    }
    setMyRequests(prev => prev.map(r => r.id === requestId ? { ...r, [statusField]: 'cancelled', [reasonField]: reason } : r))
    showSuccess('依頼を取り消しました。')
    return true
  }

  const loadContracts = async (deptNos: number[]) => {
    const { data: rows, error } = await supabase
      .from('contracts')
      .select('id, pattern, contract_type, document_type, work_place, status, created_by, created_by_dept_no, created_at, rejection_reason, sign_requested_at, signed_at, input_data, withdrawn_reason, withdrawn_by, withdrawn_at')
      .in('created_by_dept_no', deptNos)
      .in('status', ['申請中', 'SSC承認済み', '差し戻し中', '署名待ち', '取り下げ'])
      .order('created_at', { ascending: false })

    if (error) { console.error('contracts取得エラー:', error); return }
    setFlowContracts((rows || []) as Contract[])
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/login')
  }

  const isExplainNeeded = (c: Contract) => {
    const cp = c.input_data?.fields?.closingPattern
    return c.status === 'SSC承認済み' && (cp === 'face' || cp === 'print')
  }

  const explainList = flowContracts.filter(isExplainNeeded)
  const pendingList = flowContracts.filter(c => ['申請中', 'SSC承認済み'].includes(c.status) && !isExplainNeeded(c))
  const rejectedList = flowContracts.filter(c => c.status === '差し戻し中')
  const waitingList = flowContracts.filter(c => c.status === '署名待ち')
  const withdrawnList = flowContracts.filter(c => c.status === '取り下げ')
  const completedList = approvedContracts

  const hasVisibleTask = (r: MyRequest, includeCompleted: boolean) => {
    const srVisible = !!r.staff_register_status && (r.staff_register_status !== 'completed' || includeCompleted)
    const csvVisible = !!r.csv_import_status && r.csv_import_status !== 'not_required' && (r.csv_import_status !== 'completed' || includeCompleted)
    return srVisible || csvVisible
  }
  const visibleMyRequests = myRequests
    .filter(r => hasVisibleTask(r, includeCompletedRequests))
    .filter(r => {
      const q = myRequestsDebouncedSearchText.trim()
      if (!q) return true
      return (r.staff_name || '').includes(q) || (r.staff_code || '').includes(q)
    })

  const filterCards: { key: FilterKey; label: string; count: number | null; color: string; tone: 'blue' | 'orange' | 'red' | 'green' | 'gray' | 'purple'; icon: IconName }[] = [
    { key: 'pending', label: '進行中', count: pendingList.length, color: '#2F5FD0', tone: 'blue', icon: 'file' },
    { key: 'explain', label: '要説明', count: explainList.length, color: '#6B7280', tone: 'gray', icon: 'message' },
    { key: 'rejected', label: '差し戻し', count: rejectedList.length, color: '#E74C3C', tone: 'red', icon: 'refresh' },
    { key: 'waiting', label: '署名待ち', count: waitingList.length, color: '#F59E42', tone: 'orange', icon: 'pen' },
    { key: 'completed', label: '完了', count: approvedTotalCount, color: '#4CAF50', tone: 'green', icon: 'check' },
    { key: 'withdrawn', label: '取り下げ', count: withdrawnList.length, color: '#6B7280', tone: 'gray', icon: 'refresh' },
    { key: 'other', label: '依頼状況', count: visibleMyRequests.length, color: '#7C3AED', tone: 'purple', icon: 'mail' },
    { key: 'renewal', label: '更新期限管理', count: renewalCandidates.length, color: '#F59E42', tone: 'orange', icon: 'clock' },
    { key: 'pledges', label: 'アルバイト誓約書', count: pledgesPendingCount, color: '#F59E42', tone: 'orange', icon: 'file' },
  ]

  // 総合レビュー指摘B対応（2026-07-16）：契約のステータス別サブタブ（機能タブ「契約一覧」の中身）。
  // 「依頼状況」「更新期限管理」は別の機能タブとして扱うためここには含めない。
  const CONTRACT_SUB_KEYS: FilterKey[] = ['pending', 'explain', 'rejected', 'waiting', 'completed', 'withdrawn']
  const isContractGroupActive = CONTRACT_SUB_KEYS.includes(activeFilter)
  const contractSubTabs = filterCards.filter(c => CONTRACT_SUB_KEYS.includes(c.key))
  const contractsTotalCount = pendingList.length + explainList.length + rejectedList.length + waitingList.length + approvedTotalCount + withdrawnList.length
  if (isContractGroupActive) lastContractFilterRef.current = activeFilter

  // 総合レビュー指摘C対応（2026-07-16）：上部KPIカードと直下のタブが同じ7項目を重複表示しており、
  // ファーストビューの半分が同じ情報の繰り返しになっていた（レビュー指摘B・C）。
  // カードは「今日対応すべき」もの（要説明・差し戻し・署名待ち・更新期限管理）に絞り、
  // 網羅的な件数・切り替えは直下のタブ（filterCards全件）に任せる。
  const TOP_CARD_KEYS: FilterKey[] = ['explain', 'rejected', 'waiting', 'renewal']
  const topCards = filterCards.filter(c => TOP_CARD_KEYS.includes(c.key))

  const baseListForFilter: Record<FilterKey, Contract[]> = {
    pending: pendingList,
    explain: explainList,
    rejected: rejectedList,
    waiting: waitingList,
    completed: completedList,
    withdrawn: withdrawnList,
    other: [],
    renewal: [],
    pledges: [],
  }
  const baseCurrentList = baseListForFilter[activeFilter]
  const currentLabel = filterCards.find(c => c.key === activeFilter)?.label || ''

  const statusOptionsForFilter: Record<FilterKey, { value: string; label: string }[]> = {
    pending: [
      { value: '申請中', label: '申請中' },
      // 総合レビュー指摘21対応：社内案件は「承認済み」・社外案件は「SSC承認済み」と
      // カード側の表示を出し分けているため、この絞り込みピルも両方に当てはまる中立的な
      // ラベルにする（値自体は変更せず、実際のstatus文字列'SSC承認済み'のまま絞り込む）。
      { value: 'SSC承認済み', label: '承認済み' },
    ],
    explain: [],
    rejected: [],
    waiting: [],
    completed: [],
    withdrawn: [],
    other: [],
    renewal: [],
    pledges: [],
  }

  const { result: currentList, toolbar: listToolbar, searchText: contractSearchText } = useContractListToolbar(baseCurrentList, {
    statusOptions: statusOptionsForFilter[activeFilter],
    sortOptions: buildDateSortOptions<Contract>(),
    getSearchText: c => {
      const staff = c.input_data?.staff || {}
      const f = c.input_data?.fields || {}
      return [staff.name, staff.employee_number, f.workLocationName].filter(Boolean).join(' ')
    },
    searchPlaceholder: '氏名・社員番号・就業先で検索',
    resetKey: activeFilter,
  })

  const handleExplainDone = async (contractId: string) => {
    if (explainLoading) return
    setExplainLoading(true)
    const res = await fetch(`/api/contracts/${contractId}/notify-sign-request?trigger=explain`, { method: 'POST', headers: await getAuthHeader() })
    const result = await res.json().catch(() => ({}))
    if (!res.ok) {
      showError('更新に失敗しました: ' + (result.error || '不明なエラー'))
      setExplainLoading(false)
      return
    }
    const now = new Date().toISOString()
    setFlowContracts(prev => prev.map(c => c.id === contractId ? { ...c, status: '署名待ち' as ContractStatus, sign_requested_at: now } : c))
    setConfirmingExplainId(null)
    setExplainLoading(false)
  }

  if (!user) return (
    <div className="flex min-h-screen items-center justify-center bg-[#F8FAFD]">
      <p className="text-sm font-medium text-[#6B7280]">読み込み中</p>
    </div>
  )

  const handleDeleteWithdrawn = async (contractId: string) => {
    const ok = await confirmDialog(WITHDRAWN_APPLICATION_DELETE_CONFIRM)
    if (!ok) return
    setDeletingWithdrawnId(contractId)
    const { error } = await supabase.from('contracts').delete().eq('id', contractId).eq('status', '取り下げ')
    setDeletingWithdrawnId(null)
    if (error) { showError('削除に失敗しました: ' + error.message); return }
    setFlowContracts(prev => prev.filter(c => c.id !== contractId))
    showSuccess('削除しました。')
  }

  return (
    <div className="h-screen overflow-auto bg-[#F8FAFD] text-[#1F2937]">
      <header className="relative z-30 border-b border-[#E8EDF5] bg-white/90 backdrop-blur">
        <div className="mx-auto flex min-w-max max-w-[1600px] items-center justify-between px-6 py-5 lg:px-8">
          <div className="flex items-center gap-5">
            <div className="flex items-center gap-3">
              <Image src="/logo.png" alt="APパートナーズ" width={64} height={38} className="h-auto w-[64px]" />
              <div>
                <p className="text-sm font-semibold text-[#1F2937]">APパートナーズ</p>
                <p className="text-xs font-medium text-[#6B7280]">担当営業ダッシュボード</p>
              </div>
            </div>
            <div className="hidden h-8 w-px bg-[#E8EDF5] md:block" />
            <div className="hidden md:block">
              <h1 className="text-2xl font-semibold tracking-normal text-[#1F2937]">契約書管理システム</h1>
              <p className="mt-1 text-sm font-medium text-[#6B7280]">自分の申請状況を確認し、必要な対応を進められます</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <NewDocumentMenu />
            <div className="h-8 w-px bg-[#E8EDF5]" />
            <ChatbotWidget />
            <LoggedInUserChip userId={user?.id} />
            <button onClick={handleLogout} className={headerSecondaryButton}>
              <Icon name="logout" className="h-4 w-4" />
              ログアウト
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1600px] px-6 py-8 lg:px-8">
        {deptLookupError && (
          <div className="mb-6 rounded-[18px] border border-[#F7C7C1] bg-[#FDECEC] p-5 shadow-[0_10px_30px_rgba(15,23,42,.05)]">
            <p className="text-sm font-semibold text-[#E74C3C]">{deptLookupError}</p>
          </div>
        )}

        <section className="overflow-hidden rounded-[18px] border border-[#E8EDF5] bg-[radial-gradient(circle_at_20%_15%,rgba(47,95,208,.14),transparent_32%),linear-gradient(135deg,#F7FBFF_0%,#EEF5FF_48%,#FFFFFF_100%)] p-6 shadow-[0_10px_30px_rgba(15,23,42,.05)] md:p-8">
          <div className="grid gap-6 xl:grid-cols-[.8fr_1.6fr] xl:items-center">
            <div className="flex items-start gap-5">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-[#DDE8FF] text-[#2F5FD0]">
                <Icon name={filterCards.find(c => c.key === activeFilter)?.icon || 'file'} className="h-8 w-8" />
              </div>
              <div>
                <p className="text-sm font-semibold text-[#1F2937]">本日の状況</p>
                <h2 className="mt-2 text-4xl font-semibold tracking-normal text-[#2F5FD0] md:text-5xl">
                  <span className="whitespace-nowrap">{currentLabel}</span>{' '}
                  <span className="whitespace-nowrap">{activeFilter === 'other' ? visibleMyRequests.length : activeFilter === 'completed' ? approvedTotalCount : activeFilter === 'renewal' ? renewalCandidates.length : activeFilter === 'pledges' ? pledgesPendingCount : baseCurrentList.length}件</span>
                </h2>
                <p className="mt-4 text-sm font-medium leading-6 text-[#1F2937]">
                  対応が必要な案件を確認し、次のアクションへ進めてください。
                </p>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {topCards.map(card => (
                <button
                  key={card.key}
                  onClick={() => setActiveFilter(card.key)}
                  className={`rounded-[18px] border bg-white/86 p-5 text-left shadow-[0_10px_30px_rgba(15,23,42,.05)] backdrop-blur transition hover:-translate-y-0.5 hover:shadow-[0_15px_40px_rgba(15,23,42,.08)] ${activeFilter === card.key ? 'border-[#2F5FD0]' : 'border-[#E8EDF5]'}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <p className="text-sm font-semibold text-[#1F2937]">{card.label}</p>
                    <Icon name={card.icon} className="h-5 w-5 text-[#6B7280]" />
                  </div>
                  <div className="mt-5 flex items-end gap-1">
                    <span className="text-4xl font-semibold tracking-normal" style={{ color: card.color }}>{card.count}</span>
                    <span className="pb-1 text-sm font-semibold" style={{ color: card.color }}>件</span>
                  </div>
                  <div className="mt-5 h-1 w-full rounded-full" style={{ background: card.color }} />
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* 総合レビュー指摘B対応（2026-07-16）：管理部と同じ「機能タブ→ステータスのサブタブ」の
            2階層構造に変更。機能タブは「契約一覧／依頼状況／更新期限管理」の3つ */}
        <nav className="mt-6 border-b border-[#E8EDF5]">
          <div className="flex flex-nowrap gap-8">
            {[
              { key: 'contracts' as const, label: '契約一覧', icon: 'file' as IconName, count: contractsTotalCount, isActive: isContractGroupActive, onClick: () => setActiveFilter(lastContractFilterRef.current) },
              { key: 'other' as const, label: '依頼状況', icon: 'mail' as IconName, count: visibleMyRequests.length, isActive: activeFilter === 'other', onClick: () => setActiveFilter('other') },
              { key: 'renewal' as const, label: '更新期限管理', icon: 'clock' as IconName, count: renewalCandidates.length, isActive: activeFilter === 'renewal', onClick: () => setActiveFilter('renewal') },
              { key: 'pledges' as const, label: 'アルバイト誓約書', icon: 'file' as IconName, count: pledgesPendingCount, isActive: activeFilter === 'pledges', onClick: () => setActiveFilter('pledges') },
            ].map(group => (
              <button
                key={group.key}
                onClick={group.onClick}
                className={`group relative flex shrink-0 items-center gap-2 whitespace-nowrap px-1 pb-4 text-sm font-semibold transition ${group.isActive ? 'text-[#2F5FD0]' : 'text-[#1F2937] hover:text-[#2F5FD0]'}`}
              >
                <Icon name={group.icon} className="h-4 w-4" />
                {group.label}
                <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${group.isActive ? 'bg-[#2F5FD0] text-white' : 'bg-[#EEF0F5] text-[#6B7280]'}`}>{group.count}</span>
                <span className={`absolute bottom-[-1px] left-0 h-0.5 rounded-full bg-[#2F5FD0] transition-all duration-300 ${group.isActive ? 'w-full' : 'w-0 group-hover:w-full'}`} />
              </button>
            ))}
          </div>
        </nav>

        {/* 「契約一覧」機能タブの中だけに表示するステータスのサブタブ（進行中/要説明/差し戻し/署名待ち/完了/取り下げ） */}
        {isContractGroupActive && (
          <div className="mt-4">
            <SubTabBar items={contractSubTabs.map(c => ({ key: c.key, label: c.label, count: c.count ?? 0 }))} activeKey={activeFilter} onChange={setActiveFilter} />
          </div>
        )}

        {activeFilter !== 'other' && activeFilter !== 'renewal' && (
          <section className="mt-5 rounded-[18px] border border-[#E8EDF5] bg-white p-5 shadow-[0_10px_30px_rgba(15,23,42,.05)]">
            <div className="mb-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Icon name="filter" className="h-5 w-5 text-[#1F2937]" />
                <h2 className="text-base font-semibold text-[#1F2937]">絞り込み</h2>
              </div>
              <Icon name="search" className="h-5 w-5 text-[#6B7280]" />
            </div>
            <div className="[&_button]:rounded-[16px] [&_button]:font-semibold [&_input]:rounded-[16px] [&_input]:border-[#E8EDF5] [&_input]:transition [&_input:focus]:border-[#2F5FD0] [&_select]:rounded-[16px] [&_select]:border-[#E8EDF5]">
              {listToolbar}
            </div>
            {activeFilter === 'completed' && (
              <div className="mt-3 flex flex-wrap items-center gap-3">
                {!approvedSearchMode ? (
                  <>
                    <p className="text-xs font-medium text-[#6B7280]">表示は直近{APPROVED_WINDOW_DAYS}日分です。それより前は検索してください。</p>
                    <button onClick={() => runApprovedSearch(contractSearchText)} disabled={!contractSearchText.trim() || approvedSearching}
                      className="rounded-[14px] border border-[#D0DAF0] bg-white px-4 py-2 text-xs font-semibold text-[#2F5FD0] disabled:opacity-50">
                      {approvedSearching ? '検索中…' : '全期間で検索'}
                    </button>
                  </>
                ) : (
                  <>
                    <p className="text-xs font-medium text-[#6B7280]">全期間検索の結果です{approvedSearchNotice ? '（' + approvedSearchNotice + '）' : ''}</p>
                    <button onClick={fetchApprovedRecent} className="rounded-[14px] border border-[#D0DAF0] bg-white px-4 py-2 text-xs font-semibold text-[#2F5FD0]">
                      直近{APPROVED_WINDOW_DAYS}日の表示に戻す
                    </button>
                  </>
                )}
              </div>
            )}
          </section>
        )}

        {activeFilter === 'renewal' ? (
          <section className={`${cardBase} mt-5 p-6`}>
            <h2 className="mb-5 text-lg font-semibold text-[#1F2937]">更新期限管理</h2>
            <SubTabBar
              items={[
                { key: 'candidates' as const, label: '期限間近の更新候補', count: renewalCandidates.length },
                {
                  key: 'monitoring' as const,
                  label: '契約状況モニタリング',
                  count: monitoringRows.filter(r => r.topSeverity !== 1 && r.actionStatus !== '解消').length,
                },
                { key: 'wageRevision' as const, label: '最低賃金改定対応', count: wageRevisionRows.length },
              ]}
              activeKey={renewalSubTab}
              onChange={setRenewalSubTab}
            />
            {renewalSubTab === 'monitoring' && (
              <ContractMonitoringSection
                rows={monitoringRows}
                loading={monitoringLoading}
                error={monitoringError}
                onRefresh={fetchMonitoring}
                currentUserName={deptNameRef.current}
                readOnly
              />
            )}
            {renewalSubTab === 'wageRevision' && (
              <WageRevisionSection
                rows={wageRevisionRows}
                loading={wageRevisionLoading}
                error={wageRevisionError}
                onRefresh={fetchWageRevisionCandidates}
              />
            )}
            {renewalSubTab === 'candidates' && user && (
              <RenewalManagementTab
                candidates={renewalCandidates}
                loading={renewalLoading}
                updateCandidate={updateCandidate}
                searchCsvRenewal={searchCsvRenewal}
                requestCsvImport={requestCsvImport}
                switchToManualOverride={switchToManualOverride}
                copyDispatchToEmploy={copyDispatchToEmploy}
                confirmNotRenewing={confirmNotRenewing}
                setTriageMode={setTriageMode}
                setRenewalTab={setRenewalTab}
                executeBulkApply={executeBulkApply}
                currentUserId={user.id}
                currentUserEmail={user.email}
                currentUserDeptName={deptNameRef.current}
              />
            )}
          </section>
        ) : activeFilter === 'pledges' ? (
          <section className={`${cardBase} mt-5 p-6`}>
            <h2 className="mb-5 text-lg font-semibold text-[#1F2937]">アルバイト誓約書</h2>
            <PledgeListSection deptNoFilter={deptScopeRef.current.length > 0 ? deptScopeRef.current : undefined} detailBasePath="/dashboard/sales/pledges" />
          </section>
        ) : loading ? (
          <div className="py-16 text-center">
            <p className="text-sm font-medium text-[#6B7280]">読み込み中</p>
          </div>
        ) : (
          <section className={`${cardBase} mt-5 p-6`}>
            {activeFilter === 'other' ? (
              <div className="mb-5 flex flex-col gap-3">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <h2 className="text-lg font-semibold text-[#1F2937]">依頼状況一覧（{visibleMyRequests.length}件）</h2>
                  <label className="flex items-center gap-2 text-sm font-medium text-[#6B7280]">
                    <input
                      type="checkbox"
                      checked={includeCompletedRequests}
                      onChange={e => setIncludeCompletedRequests(e.target.checked)}
                      className="h-4 w-4 rounded border-[#E8EDF5] accent-[#2F5FD0]"
                    />
                    完了したものも表示する
                  </label>
                </div>
                <input
                  value={myRequestsSearchText}
                  onChange={e => setMyRequestsSearchText(e.target.value)}
                  placeholder="社員番号または氏名で検索"
                  className="h-12 w-full rounded-2xl border border-[#E8EDF5] bg-white px-4 text-sm font-medium text-[#1F2937] outline-none transition placeholder:text-[#8B98B1] focus:border-[#2F5FD0] sm:max-w-xs"
                />
                <div className="flex flex-wrap items-center gap-3">
                  {myRequestsWindowMode === 'recent' ? (
                    <>
                      <p className="text-xs font-medium text-[#6B7280]">表示は直近{REQUEST_WINDOW_DAYS}日分です。それより前は全期間で表示してください。</p>
                      <button onClick={() => loadMyRequests(deptNameRef.current, 'all')}
                        className="rounded-[14px] border border-[#D0DAF0] bg-white px-4 py-2 text-xs font-semibold text-[#2F5FD0]">
                        全期間で表示
                      </button>
                    </>
                  ) : (
                    <>
                      <p className="text-xs font-medium text-[#6B7280]">全期間の依頼を表示しています。</p>
                      <button onClick={() => loadMyRequests(deptNameRef.current, 'recent')}
                        className="rounded-[14px] border border-[#D0DAF0] bg-white px-4 py-2 text-xs font-semibold text-[#2F5FD0]">
                        直近{REQUEST_WINDOW_DAYS}日の表示に戻す
                      </button>
                    </>
                  )}
                </div>
              </div>
            ) : (
              <h2 className="mb-5 text-lg font-semibold text-[#1F2937]">{currentLabel}（{currentList.length}件）</h2>
            )}

            {activeFilter === 'other' ? (
              myRequestsLoading ? (
                <p className="py-8 text-sm font-medium text-[#6B7280]">読み込み中</p>
              ) : visibleMyRequests.length === 0 ? (
                <p className="py-8 text-sm font-medium text-[#6B7280]">該当する依頼はありません。</p>
              ) : (
                <div className="grid gap-3">
                  {visibleMyRequests.map(r => <MyRequestCard key={r.id} r={r} includeCompleted={includeCompletedRequests} onCancel={handleSelfCancelRequest} />)}
                </div>
              )
            ) : currentList.length === 0 ? (
              <p className="py-8 text-sm font-medium text-[#6B7280]">該当する書類はありません。</p>
            ) : (
              <div className="grid gap-3">
                {currentList.map(c => (
                  <ContractCard
                    key={c.id}
                    contract={c}
                    router={router}
                    confirmingExplainId={confirmingExplainId}
                    setConfirmingExplainId={setConfirmingExplainId}
                    deletingWithdrawnId={deletingWithdrawnId}
                    handleDeleteWithdrawn={handleDeleteWithdrawn}
                    isExplainNeeded={isExplainNeeded}
                    explainLoading={explainLoading}
                    handleExplainDone={handleExplainDone}
                  />
                ))}
              </div>
            )}

            {activeFilter === 'completed' && approvedHasMore && !approvedSearchMode && (
              <div className="mt-5 flex justify-center">
                <button onClick={loadMoreApproved} disabled={approvedLoadingMore}
                  className="rounded-2xl border border-[#D0DAF0] bg-white px-6 py-3 text-sm font-semibold text-[#2F5FD0] disabled:opacity-50">
                  {approvedLoadingMore ? '読み込み中…' : 'さらに読み込む'}
                </button>
              </div>
            )}

            {activeFilter === 'other' && (
              <div className="mt-5 border-t border-[#E8EDF5] pt-4 text-center">
                <span className="text-xs font-medium text-[#6B7280]">更新回答機能は準備中です。</span>
              </div>
            )}
          </section>
        )}
      </main>
    </div>
  )
}

function MyRequestCard({ r, includeCompleted, onCancel }: {
  r: MyRequest
  includeCompleted: boolean
  onCancel: (
    requestId: string,
    statusField: 'staff_register_status' | 'csv_import_status',
    reasonField: 'staff_register_cancel_reason' | 'csv_import_cancel_reason',
    reason: string
  ) => Promise<boolean>
}) {
  const badge = (status: string) => {
    const isDone = status === 'completed'
    const isCancelled = status === 'cancelled'
    const label = isDone ? '完了' : isCancelled ? '要確認・取消済み' : status === 'in_progress' ? '対応中' : '未対応'
    const tone = isDone ? 'green' : isCancelled ? 'orange' : 'blue'
    return <Pill tone={tone}>{label}</Pill>
  }
  const taskVisible = (status: string | null) => !!status && status !== 'not_required' && (status !== 'completed' || includeCompleted)

  const showStaffRegister = taskVisible(r.staff_register_status)
  const showCsvImport = taskVisible(r.csv_import_status)
  const hasCancelled = r.staff_register_status === 'cancelled' || r.csv_import_status === 'cancelled'

  return (
    <article className={`${cardBase} p-5 ${hasCancelled ? 'border-[#FFE2C7] bg-[#FFF8F1]' : ''}`}>
      <div className="grid gap-4 lg:grid-cols-[minmax(200px,1.1fr)_minmax(160px,.8fr)_minmax(200px,.9fr)_minmax(200px,.9fr)_1.4fr] lg:items-start">
        <div className="min-w-0">
          {r.staff_dept && <p className="text-sm font-medium text-[#6B7280]">{r.staff_dept}</p>}
          <p className="mt-1 break-words text-[22px] font-semibold leading-7 text-[#1F2937]">{r.staff_name || '-'}</p>
        </div>

        <div className="min-w-0">
          <p className="mb-2 text-xs font-semibold text-[#6B7280]">社員番号</p>
          <p className="break-words text-sm font-medium leading-6 text-[#1F2937]">{r.staff_code || '-'}</p>
          {r.staff_hire_date && <p className="mt-1 text-xs font-medium text-[#6B7280]">入社日 {formatDate(new Date(r.staff_hire_date))}</p>}
        </div>

        <div className="min-w-0">
          <p className="mb-2 text-xs font-semibold text-[#6B7280]">就業先</p>
          <div className="flex items-start gap-2">
            <Icon name="map" className="mt-0.5 h-4 w-4 shrink-0 text-[#2F5FD0]" />
            <p className="break-words text-sm font-medium leading-6 text-[#1F2937]">{r.client_name || '-'}</p>
          </div>
        </div>

        <div className="min-w-0">
          <p className="mb-2 text-xs font-semibold text-[#6B7280]">依頼日時</p>
          <p className="break-words text-sm font-medium leading-6 text-[#1F2937]">{formatDateTime(r.requested_at)}</p>
          <p className="mb-1 mt-3 text-xs font-semibold text-[#6B7280]">申請者</p>
          <p className="break-words text-sm font-medium leading-6 text-[#1F2937]">
            {r.requested_by_dept && <span className="text-[#6B7280]">{r.requested_by_dept}　</span>}
            {r.requested_by_name || '-'}
          </p>
        </div>

        <div className="grid gap-3">
          {showStaffRegister && (
            <div className="rounded-2xl border border-[#E8EDF5] bg-white px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  {badge(r.staff_register_status as string)}
                  <span className="text-sm font-semibold text-[#1F2937]">スタッフマスタ登録</span>
                </div>
              </div>
              {r.staff_register_status === 'cancelled' && r.staff_register_cancel_reason && (
                <p className="mt-2 break-words text-sm font-medium leading-6 text-[#F59E42]">取消理由：{r.staff_register_cancel_reason}</p>
              )}
              {r.staff_register_status === 'pending' && (
                <SelfCancelControl
                  onConfirm={reason => onCancel(r.id, 'staff_register_status', 'staff_register_cancel_reason', reason)}
                />
              )}
            </div>
          )}
          {showCsvImport && (
            <div className="rounded-2xl border border-[#E8EDF5] bg-white px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  {badge(r.csv_import_status as string)}
                  <span className="break-words text-sm font-semibold text-[#1F2937]">
                    CSVインポート{r.system_type ? `（${r.system_type}${r.dispatch_start_date ? '・派遣開始日 ' + formatDate(new Date(r.dispatch_start_date)) : ''}）` : ''}
                  </span>
                </div>
              </div>
              {r.csv_import_status === 'cancelled' && r.csv_import_cancel_reason && (
                <p className="mt-2 break-words text-sm font-medium leading-6 text-[#F59E42]">取消理由：{r.csv_import_cancel_reason}</p>
              )}
              {r.csv_import_status === 'pending' && (
                <SelfCancelControl
                  onConfirm={reason => onCancel(r.id, 'csv_import_status', 'csv_import_cancel_reason', reason)}
                />
              )}
            </div>
          )}
        </div>
      </div>
    </article>
    )
}

// 依頼（スタッフマスタ登録依頼／CSVインポート依頼）の自己取消用インライン操作。
// 管理部ダッシュボードのStatusRow（取消フォーム）と同じUXパターンを踏襲（2026-07-24新設）。
function SelfCancelControl({ onConfirm }: { onConfirm: (reason: string) => Promise<boolean> }) {
  const [showForm, setShowForm] = useState(false)
  const [reasonText, setReasonText] = useState('')
  const [reasonError, setReasonError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const submit = async () => {
    if (!reasonText.trim()) { setReasonError('取消理由を入力してください'); return }
    setReasonError(null)
    setSubmitting(true)
    const ok = await onConfirm(reasonText.trim())
    setSubmitting(false)
    if (ok) setShowForm(false)
  }

  if (!showForm) {
    return (
      <button
        onClick={() => setShowForm(true)}
        className="mt-2 rounded-xl border border-[#E8EDF5] bg-white px-3 py-1.5 text-xs font-semibold text-[#6B7280] transition hover:border-[#DC2626] hover:text-[#DC2626]">
        この依頼を取り消す
      </button>
    )
  }

  return (
    <div className="mt-3 grid gap-2">
      <input
        value={reasonText}
        onChange={e => setReasonText(e.target.value)}
        placeholder="取消理由を入力"
        className="h-10 rounded-xl border border-[#E8EDF5] bg-white px-3 text-xs font-medium text-[#1F2937] outline-none transition placeholder:text-[#8B98B1] focus:border-[#2F5FD0]"
      />
      <ValidationBanner message={reasonError} />
      <div className="flex flex-wrap gap-2">
        <button onClick={submit} disabled={submitting}
          className="inline-flex h-9 items-center justify-center rounded-xl bg-[#DC2626] px-3 text-xs font-semibold text-white transition hover:bg-[#B91C1C] disabled:opacity-60">
          {submitting ? '送信中...' : 'この理由で取り消す'}
        </button>
        <button onClick={() => { setShowForm(false); setReasonText(''); setReasonError(null) }} disabled={submitting}
          className="inline-flex h-9 items-center justify-center rounded-xl border border-[#E8EDF5] bg-white px-3 text-xs font-semibold text-[#6B7280] transition hover:border-[#2F5FD0] hover:text-[#2F5FD0]">
          キャンセル
        </button>
      </div>
    </div>
  )
}
