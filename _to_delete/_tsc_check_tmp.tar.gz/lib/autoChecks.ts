// ===== 自動チェック機能（SYSTEM_DESIGN.md 7-5章）の判定ロジック本体 =====
// 申請保存時（/apply の handleSubmitContract）に呼び出し、結果を
// contracts.auto_check_results（詳細）・contracts.warning_level（none/yellow/red）に保存する。
// 2026-07-06 実装。

import { formatDateJp } from '@/lib/dateFormat'

export type WarningLevel = 'none' | 'yellow' | 'red'

export interface AutoCheckResult {
  type: string
  level: 'yellow' | 'red'
  message: string
}

export interface MinimumWageRow {
  dept_no: number
  hourly_wage: number
  effective_from: string // YYYY-MM-DD
}

// 最低賃金マスタ（minimum_wage_master。department_masterとは別のテーブル）に、対象部門の登録が1件も無いかどうか。
// 7-5章の例外規定：「最低賃金マスタに登録が無い場合のみ、申請不可（強制ブロック）」。
// 対象は勤務地が「現場」の場合のみ（「社内」は最低賃金チェック自体の対象外のため呼び出し不要）。
export function isMinimumWageMasterMissing(
  allRows: MinimumWageRow[],
  deptNo: number | null | undefined
): boolean {
  if (deptNo === null || deptNo === undefined) return false // 部門が特定できないケースは別途ハンドリング（ここではブロックしない）
  return !allRows.some(r => r.dept_no === deptNo)
}

const diffDays = (dateA: string, dateB: string) => {
  const a = new Date(dateA + 'T00:00:00').getTime()
  const b = new Date(dateB + 'T00:00:00').getTime()
  return Math.round((a - b) / (1000 * 60 * 60 * 24))
}

export interface AutoCheckInput {
  // 2026-07-08追加：パターンB（就業条件明示書）はSTEP7（給与入力）自体が存在せず、
  // salaryType/basicSalary等が未入力のまま初期値（時給・0円）で渡ってくるため、
  // 賃金起因のチェック（金額異常値・最低賃金）はpattern==='B'の場合は必ずスキップする。
  pattern: string // 'A' | 'B' | 'C'
  workPlace: string // '現場' | '社内'
  contractType: string // '有期契約' | '無期契約' | '正社員' | 'アルバイト'
  salaryType: string // '時給' | '日給' | '月給'
  basicSalary: number
  // 2026-07-07追加：最低賃金の時給換算に含めるため。定額残業手当（overtimePay）は
  // 時間外労働の対価のため、最低賃金法上の除外賃金にあたり計算に含めない。
  rolePay: number
  skillPay: number
  salesPay: number
  housingPay: number
  overtimePay: number
  hasEmployInsurance: boolean
  hasSocialInsurance: boolean
  workingHoursH: number
  workingHoursM: number
  monthlyStandardHours: number | null
  deptNo: number | null
  staffHiredAt: string | null // staff.hired_at（YYYY-MM-DD）
  employStart: string
  employEnd: string
  contractStartDate: string // 無期契約・正社員は雇用期間ではなくこちら（契約条件適用開始日）を使う
  dispatchStart: string
  dispatchEnd: string
  trialPeriod: string // '有' | '無' | ''
  minimumWageRowsForDept: MinimumWageRow[] // 対象部門の行のみに絞り込んだもの
}

// ① 金額チェック（異常値検出）※7-5章の表より。定額残業代の異常値チェックは対象外（2026-07-06 伊藤さん確認：不要と判断）
function checkAmountAnomaly(input: AutoCheckInput): AutoCheckResult | null {
  if (input.pattern === 'B') return null // 2026-07-08：就業条件明示書は給与入力STEPが無いためスキップ
  const { salaryType, basicSalary } = input
  if (salaryType === '時給') {
    if (basicSalary < 1500 || basicSalary > 5000) {
      return { type: 'amount_anomaly_hourly', level: 'red', message: `時給として入力された金額（${basicSalary.toLocaleString()}円）が、通常の範囲（1,500円〜5,000円）から外れています。入力ミスがないかご確認ください。` }
    }
  } else if (salaryType === '日給') {
    if (basicSalary < 8000 || basicSalary > 50000) {
      return { type: 'amount_anomaly_daily', level: 'red', message: `日給として入力された金額（${basicSalary.toLocaleString()}円）が、通常の範囲（8,000円〜50,000円）から外れています。入力ミスがないかご確認ください。` }
    }
  } else if (salaryType === '月給') {
    if (basicSalary < 150000 || basicSalary > 800000) {
      return { type: 'amount_anomaly_monthly', level: 'red', message: `月給として入力された金額（${basicSalary.toLocaleString()}円）が、通常の範囲（150,000円〜800,000円）から外れています。入力ミスがないかご確認ください。` }
    }
  }
  return null
}

// ②の時給換算・適用マスタ行の選定ロジック本体（2026-07-29：checkMinimumWageから抽出）。
// 更新期限管理タブ「最低賃金改定対応」サブタブ（既存契約の遡及チェック）でも同じ計算式を
// 再利用するため、checkMinimumWageの内部計算部分だけを独立した関数として切り出した。
// checkMinimumWage自体の外部向けの挙動・シグネチャは変更していない。
export interface WageCheckDetail {
  hourlyEquivalent: number
  targetRow: MinimumWageRow
}

export function computeWageCheckDetail(input: Pick<AutoCheckInput,
  'salaryType' | 'basicSalary' | 'rolePay' | 'skillPay' | 'salesPay' | 'housingPay' |
  'workingHoursH' | 'workingHoursM' | 'monthlyStandardHours' |
  'employStart' | 'employEnd' | 'contractStartDate' | 'minimumWageRowsForDept'
>): WageCheckDetail | null {
  if (input.minimumWageRowsForDept.length === 0) return null

  // 時給換算した金額を算出
  // 2026-07-07修正：月給制で基本給のみを時給換算していたため、役職手当・職能給・営業手当・
  // 住宅手当を上乗せしている場合に実際の実質時給より低く算出され、誤って最低賃金割れと
  // 判定してしまう不具合があった（伊藤さん確認済み）。最低賃金法上、精皆勤手当・通勤手当・
  // 家族手当・時間外等の割増賃金・賞与は算定対象から除外できるが、役職手当・職能給・営業手当・
  // 住宅手当はいずれも除外規定に該当しないため算入する。定額残業手当（overtimePay）は
  // 時間外労働の対価のため引き続き除外する。
  const allowanceTotal = input.rolePay + input.skillPay + input.salesPay + input.housingPay
  let hourlyEquivalent: number | null = null
  if (input.salaryType === '時給') {
    hourlyEquivalent = input.basicSalary
  } else if (input.salaryType === '日給') {
    const dailyHours = input.workingHoursH + input.workingHoursM / 60
    if (dailyHours > 0) hourlyEquivalent = input.basicSalary / dailyHours
  } else if (input.salaryType === '月給') {
    if (input.monthlyStandardHours && input.monthlyStandardHours > 0) {
      hourlyEquivalent = (input.basicSalary + allowanceTotal) / input.monthlyStandardHours
    }
  }
  if (hourlyEquivalent === null) return null // 換算できない場合は判定不能

  // 無期契約・正社員は雇用期間（employStart/employEnd）を使わず、契約条件適用開始日（contractStartDate）を使う仕様のため、
  // こちらが空の場合のフォールバックとして必ず含める（2026-07-07修正：この考慮漏れで正社員の最低賃金チェックが常にスキップされていた）。
  //
  // 2026-08-12修正（M-15対応）：上記2026-07-07修正はcontractStartDateを「判定基準日」に
  // そのまま使っていたが、これは「雇用期間の終了日」ではなく「契約が始まった日」であるため、
  // 契約開始後に最低賃金が改定されると、改定日がcontractStartDateより後になり
  // applicableRowsの絞り込み条件（effective_from <= periodEnd）に一切ヒットせず、
  // 無期契約・正社員は新しい改定を永久に検知できない不具合があった（有期契約は
  // employEnd＝実際の雇用終了日が入るため、この問題は発生しない）。
  // 無期契約・正社員は「今も雇用が続いている＝今日時点で有効な最低賃金と比較すべき」ため、
  // employStart/employEndが共に空でcontractStartDateのみがある場合は、
  // contractStartDateの代わりに今日の日付（JST基準）を判定基準日として使う。
  let periodEnd = input.employEnd || input.employStart || null
  if (!periodEnd && input.contractStartDate) {
    const jstTodayFormat = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tokyo' }) // 'YYYY-MM-DD'形式
    periodEnd = jstTodayFormat.format(new Date())
  }
  if (!periodEnd) return null

  // 雇用期間の終了日までに適用開始済みの行の中から、最も新しい（＝適用開始日が最も遅い）行を採用する。
  // 該当する行が無い場合（雇用期間の終了日より後にしか改定が無い＝マスタ登録より前の契約等）は、
  // 登録されている中で最も古い行を代わりに使う（判定不能で見逃すより、既知の中で最も近い基準で判定する方針）。
  const applicableRows = input.minimumWageRowsForDept.filter(r => r.effective_from <= periodEnd)
  const targetRow = applicableRows.length > 0
    ? applicableRows.reduce((latest, r) => r.effective_from > latest.effective_from ? r : latest)
    : input.minimumWageRowsForDept.reduce((earliest, r) => r.effective_from < earliest.effective_from ? r : earliest)

  return { hourlyEquivalent, targetRow }
}

// ② 最低賃金チェック（現場のみ・部門×適用開始日単位）
// 2026-07-07決定：雇用期間中に最低賃金の改定をまたぐ場合、改定後（＝雇用期間中で最も適用開始日が新しいもの）の
// 金額1本でチェックするシンプルな設計に変更。最低賃金は下がることを想定しないため、最新の基準を満たしていれば
// それより前の期間も自動的に満たしている、という考え方（過去の「区間ごとに別々にチェック」という設計から変更）。
function checkMinimumWage(input: AutoCheckInput): AutoCheckResult[] {
  const results: AutoCheckResult[] = []
  if (input.pattern === 'B') return results // 2026-07-08：就業条件明示書は給与入力STEPが無いためスキップ
  if (input.workPlace !== '現場') return results // 社内は対象外（2026-07-03最終決定）

  const detail = computeWageCheckDetail(input)
  if (!detail) return results
  const { hourlyEquivalent, targetRow } = detail

  if (hourlyEquivalent < targetRow.hourly_wage) {
    results.push({
      type: 'minimum_wage_violation',
      level: 'red',
      message: `${formatDateJp(targetRow.effective_from)}時点の最低賃金（時給${targetRow.hourly_wage.toLocaleString()}円）に対して、入力内容の時給換算額（約${Math.floor(hourlyEquivalent).toLocaleString()}円）が下回っています。`,
    })
  }

  return results
}

// ③ 就業規則との整合チェック（7-5章の表より。定額残業代の異常値チェック分の重複は除く）
function checkWorkRules(input: AutoCheckInput): AutoCheckResult[] {
  const results: AutoCheckResult[] = []
  const { contractType, employStart, employEnd, contractStartDate, dispatchEnd, trialPeriod, salaryType, overtimePay, hasEmployInsurance, hasSocialInsurance, staffHiredAt } = input

  // 1. 試用期間：新規入社なのに試用期間「なし」
  //    アルバイトは「試用期間不要（有期契約と同じ扱い）」と決定済みのため対象外（2026-07-02決定）
  //    2026-07-07決定：入社日と雇用開始日が完全一致の場合のみ「新規入社」としていたが、人材派遣業では
  //    正社員でも案件変更のたびに契約書を再締結することが多く、その都度警告が出るとSSCの一括承認の妨げになる
  //    ため、「入社日から30日以内」も新規入社とみなす範囲に含め、それ以外（明らかな契約更新）は対象外にする。
  //    正社員・無期契約はemployStartではなくcontractStartDate（契約条件適用開始日）を使う。
  const noTrialCheckRelevantDate = (contractType === '正社員' || contractType === '無期契約') ? contractStartDate : employStart
  const daysSinceHire = (staffHiredAt && noTrialCheckRelevantDate)
    ? Math.abs(diffDays(noTrialCheckRelevantDate, staffHiredAt))
    : null
  const isProbableNewHire = daysSinceHire !== null && daysSinceHire <= 30
  if (contractType !== 'アルバイト' && isProbableNewHire && trialPeriod === '無') {
    results.push({
      type: 'no_trial_new_hire',
      level: 'yellow',
      message: '新規入社（入社日が雇用開始日と同日または近い日付）なのに、試用期間が「なし」に設定されています。契約社員第8条・正社員第13条により、原則として試用期間を設けることになっています。',
    })
  }

  // 2. 雇用期間：有期契約なのに終了日が空欄（現状のSTEP5バリデーションで既に必須化されているため通常は発生しない防御的チェック）
  if ((contractType === '有期契約' || contractType === 'アルバイト') && employStart && !employEnd) {
    results.push({
      type: 'fixed_term_no_end_date',
      level: 'yellow',
      message: '有期契約なのに雇用期間の終了日が入力されていません。契約社員第7条に基づき、終了日を確認してください。',
    })
  }

  // 3. 雇用期間の上限：有期契約の期間が1年超
  if ((contractType === '有期契約' || contractType === 'アルバイト') && employStart && employEnd && diffDays(employEnd, employStart) > 366) {
    results.push({
      type: 'fixed_term_over_1year',
      level: 'yellow',
      message: '有期契約の雇用期間が1年を超えています。就業規則第3条により、雇用期間は原則1年以内と定められています。',
    })
  }

  // 4. 社会保険：月給者なのに全未加入
  if (salaryType === '月給' && !hasEmployInsurance && !hasSocialInsurance) {
    results.push({
      type: 'insurance_all_none',
      level: 'yellow',
      message: '月給者ですが、雇用保険・社会保険のいずれも未加入に設定されています。契約社員第10条により、月給者は社会保険への加入が原則です。',
    })
  }

  // 5. 定額残業代：月給以外で定額残業代が設定されている
  if (salaryType !== '月給' && overtimePay > 0) {
    results.push({
      type: 'overtime_allowance_not_monthly',
      level: 'yellow',
      message: '時給・日給の契約で定額残業代が設定されています。定額残業代は月給者向けの制度のため、設定内容をご確認ください。',
    })
  }

  // 6. 雇用期間と派遣期間：雇用期間の終了日が派遣期間の終了日と一致していない
  // 2026-07-29仕様変更：STEP5バリデーションが「派遣終了日と完全一致」から「派遣終了日と同じかそれより後」に
  // 緩和されたため、本来は同じはずの日付が意図せずずれてしまう入力ミスが起こりうる。前後どちらの方向のズレも
  // 見落とすと重大な誤りになりうるため、伊藤さんの指示により両方向とも警告（黄色）で検知する。
  if (employEnd && dispatchEnd && employEnd < dispatchEnd) {
    results.push({
      type: 'employ_period_shorter_than_dispatch',
      level: 'yellow',
      message: '雇用期間の終了日が、派遣期間の終了日より前になっています。内容に矛盾がないかご確認ください。',
    })
  }
  if (employEnd && dispatchEnd && employEnd > dispatchEnd) {
    results.push({
      type: 'employ_period_longer_than_dispatch',
      level: 'yellow',
      message: '雇用期間の終了日が、派遣期間の終了日より後になっています。意図した内容かご確認ください。',
    })
  }

  return results
}

// ===== アルバイト誓約書（pledges）用の自動チェック（2026-07-24追加） =====
// 伊藤さん指定：「金額異常値・最低賃金を行うこととし、クライアント先・自社拠点ともに共通」。
// 雇用契約書と異なり就業規則整合チェックは対象外（誓約書には保険・試用期間等の項目自体が無いため）。
// 金額の正常範囲は雇用契約書（checkAmountAnomaly）と同じ基準を使う。
export interface PledgeAutoCheckInput {
  salaryType: string // '時給' | '日給'（誓約書に月給は無い）
  basicSalary: number
  rolePay: number
  skillPay: number
  salesPay: number
  deptNo: number | null // 対象スタッフの所属部門（最低賃金マスタの参照キー）
  periodEnd: string | null // 就業日程の最終日（YYYY-MM-DD）。最低賃金の適用行の選定に使う
  dailyStandardHours: number // 日給→時給換算に使う1日の基準時間（誓約書の給与計算基準＝7時間）
  minimumWageRowsForDept: MinimumWageRow[]
}

export function runPledgeAutoChecks(input: PledgeAutoCheckInput): { results: AutoCheckResult[]; overallLevel: WarningLevel } {
  const results: AutoCheckResult[] = []

  // ① 金額異常値（雇用契約書と同じ正常範囲）
  if (input.salaryType === '時給') {
    if (input.basicSalary < 1500 || input.basicSalary > 5000) {
      results.push({ type: 'amount_anomaly_hourly', level: 'red', message: `時給として入力された金額（${input.basicSalary.toLocaleString()}円）が、通常の範囲（1,500円〜5,000円）から外れています。入力ミスがないかご確認ください。` })
    }
  } else if (input.salaryType === '日給') {
    if (input.basicSalary < 8000 || input.basicSalary > 50000) {
      results.push({ type: 'amount_anomaly_daily', level: 'red', message: `日給として入力された金額（${input.basicSalary.toLocaleString()}円）が、通常の範囲（8,000円〜50,000円）から外れています。入力ミスがないかご確認ください。` })
    }
  }

  // ② 最低賃金（クライアント先・自社拠点とも共通で実施）
  //    手当（役職・職能・営業）は雇用契約書と同じ考え方で時給換算に算入する。
  //    対象部門にマスタ登録が無い場合は判定不能のためスキップ（誓約書は申請ブロックまではしない）。
  if (input.minimumWageRowsForDept.length > 0) {
    let hourlyEquivalent: number | null = null
    if (input.salaryType === '時給') {
      hourlyEquivalent = input.basicSalary // 時給制は雇用契約書と同様、基本給（時給）のみで判定
    } else if (input.salaryType === '日給') {
      if (input.dailyStandardHours > 0) {
        hourlyEquivalent = (input.basicSalary + input.rolePay + input.skillPay + input.salesPay) / input.dailyStandardHours
      }
    }
    if (hourlyEquivalent !== null && input.periodEnd) {
      const applicableRows = input.minimumWageRowsForDept.filter(r => r.effective_from <= input.periodEnd!)
      const targetRow = applicableRows.length > 0
        ? applicableRows.reduce((latest, r) => r.effective_from > latest.effective_from ? r : latest)
        : input.minimumWageRowsForDept.reduce((earliest, r) => r.effective_from < earliest.effective_from ? r : earliest)
      if (hourlyEquivalent < targetRow.hourly_wage) {
        results.push({
          type: 'minimum_wage_violation',
          level: 'red',
          message: `${formatDateJp(targetRow.effective_from)}時点の最低賃金（時給${targetRow.hourly_wage.toLocaleString()}円）に対して、入力内容の時給換算額（約${Math.floor(hourlyEquivalent).toLocaleString()}円）が下回っています。`,
        })
      }
    }
  }

  const overallLevel: WarningLevel = results.some(r => r.level === 'red')
    ? 'red'
    : results.some(r => r.level === 'yellow')
      ? 'yellow'
      : 'none'

  return { results, overallLevel }
}

export function runAutoChecks(input: AutoCheckInput): { results: AutoCheckResult[]; overallLevel: WarningLevel } {
  const results: AutoCheckResult[] = []

  const amount = checkAmountAnomaly(input)
  if (amount) results.push(amount)

  results.push(...checkMinimumWage(input))
  results.push(...checkWorkRules(input))

  const overallLevel: WarningLevel = results.some(r => r.level === 'red')
    ? 'red'
    : results.some(r => r.level === 'yellow')
      ? 'yellow'
      : 'none'

  return { results, overallLevel }
}
